import {
  InternalError,
  ConflictError,
  ForbiddenError,
  ValidateUserError,
  MinorUserError,
  JointUserError
} from '../../core/ApiError';
import { logHIDError, logger, logHIDPayload, logHIDResponse } from '../../core/Logger';
import { produce } from '../../kafka';
import generateAdminToken from '../../helpers/adminToken';
import { prepareKafkaResponse, getUserId } from '../access';
import axios from 'axios';
import moment from 'moment';
import updateStatistics from '../../helpers/statistics';
import * as config from '../../config';
import messages from '../../messages';
import { kafkaTopics } from '../../config';
import { registrationCountries } from '../../data/registrationCountry';
import { generateUserToken } from '../access/index';

export const validateNewUser = async (
  body: { Type: string; Key: string; NationalId: string; Id: string },
  tracingHeaders: any,
  platform: string,
  country?: string
) => {
  try {
    const authorization = await generateAdminToken(tracingHeaders);
    if (body.Type == 'Cif') {
      const data = {
        topic: 't24Request',
        route: `customer/${body.Key}`,
        authorization: `Bearer ${authorization}`,
        country
      };
      const producerData = await produce(data, tracingHeaders);
      const result = await prepareKafkaResponse(producerData);
      if (!result[0]) {
        throw new InternalError('cif does not exist');
      }
      if (result[0]?.LegalId != body.NationalId) {
        throw new InternalError('invalid legal id for customer');
      }
    }

    const data = {
      route: `admin/register/validate`,
      method: 'post',
      authorization: `Bearer ${authorization}`,
      body,
      country
    };

    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);
    updateStatistics(config.statistics.successUserValidation, {
      user: body.Id,
      userType: body.Type,
      userKey: body.Key,
      date: new Date(),
      type: 'validate registration',
      platform,
      success: true
    }).catch((e) =>
      logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
    );
    return { token: result.Token, username: result.Username, otpIdentity: result.OTPIdentity };
  } catch (e) {
    logger.error(`functionName: validateNewUser - ${e.message}`);
    if (e.message === 'cif does not exist') {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'cif does not exist',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );

      throw new InternalError();
    }
    if (e.message === 'invalid legal id for customer') {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'invalid legal id for customer',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );

      throw new InternalError();
    }
    if (e.message === messages.authentication.corporateError.en) {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'not Individual Customers',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );

      throw new ValidateUserError();
    }

    if (e.message === messages.authentication.registered.en) {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'Customer already registered',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );

      throw new InternalError();
    }

    if (e.message === messages.authentication.minorUserRegistration.en) {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'Minor Customer',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );
      throw new MinorUserError(
        'Minor Customers are not allowed to have a mobile banking user. Please contact us for any inquiries or requests.'
      );
    }
    if (e.message === messages.authentication.jointUserRegistration.en) {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'Joint Customer',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );
      throw new JointUserError(
        'Joint Customers are not allowed to have a mobile banking user. Please contact us for any inquiries or requests.'
      );
    } else {
      updateStatistics(config.statistics.failedUserValidation, {
        user: body.Id,
        userType: body.Type,
        userKey: body.Key,
        date: new Date(),
        type: 'validate registration',
        reason: 'Validation Failed',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:validateNewUser - err:${e.message}`)
      );

      throw new InternalError();
    }
  }
};

export const registerNewUser = async (
  body: {
    Token: string;
    OTP: string;
    Username: string;
    password: string;
  },
  platform: string,
  tracingHeaders?: any,
  country?: string
) => {
  try {
    logger.debug(
      `userName : ${body.Username} , password: ${body.password} , Token: ${body.Token}, OTP: ${body.OTP} `
    );
    const authorization = await generateAdminToken(tracingHeaders);
    await createT24User(body, `Bearer ${authorization}`, tracingHeaders, platform, country);
    const hidToken = await hidClientAuthentication(tracingHeaders);
    const hidUser = await getUserId(body.Username, hidToken, false, tracingHeaders);
    if (hidUser) await removeHidUser(hidUser, hidToken);
    return createHidUser(body, hidToken, platform, tracingHeaders);
  } catch (e) {
    logHIDError(e, body?.Username || '');
    logger.error(`the last catch in registration -REGISTER ERROR- err: ${e.message}`);
    if (e.message === messages.authentication.conflict.en) {
      throw new ConflictError();
    } else if (e.message === messages.authentication.invalidOtp.en) {
      throw new ForbiddenError(messages.authentication.invalidOtp.en);
    } else throw new InternalError(e.message);
  }
};

export const linkToExistingUser = async (
  body: {
    Token: string;
    OTP: string;
    Username: string;
  },
  refreshToken: string,
  platform: string,
  authorization: string,
  tracingHeaders?: any,
  country?: string
) => {
  try {
    await createT24User(body, authorization, tracingHeaders, platform, country);
    return generateUserToken(body.Username, '', refreshToken, '', platform, null, tracingHeaders);
  } catch (e) {
    logger.error(e);
    if (e.message === messages.authentication.invalidOtp.en) {
      throw new ForbiddenError(messages.authentication.invalidOtp.en);
    } else throw new InternalError();
  }
};

export const hidClientAuthentication = async (tracingHeaders: any) => {
  try {
    const url = config.hidCredentials.loginUrl;
    const body = `grant_type=client_credentials&scope=openid`;
    const auth = {
      username: config.hidCredentials.clientId,
      password: config.hidCredentials.clientSecret
    };

    logHIDPayload(
      'functionName: hidClientAuthentication - hidClientAuth',
      url,
      `HID BODY :static`,
      `Headers: willTimeoutAfter: ${config.promiseTimeout} , Auth: auth-Bearer`
    );

    const result = await axios.post(url, body, {
      auth,
      timeout: config.promiseTimeout,
      headers: tracingHeaders
    });

    logHIDResponse(' functionName: hidClientAuthentication - hidClientAuth', url, `HID Tok`);

    return result.data.access_token;
  } catch (error) {
    logger.error(`functionName: hidClientAuthentication -REGISTER- ERROR  ${error.message}`);
    logHIDError(error, '', `functionName: hidClientAuthentication`);
    throw new InternalError(error.message);
  }
};

export const createHidUser = async (
  body: any,
  auth: string,
  platform: string,
  tracingHeaders: any
) => {
  try {
    const requestBody = {
      schemas: [
        'urn:ietf:params:scim:schemas:core:2.0:User',
        'urn:hid:scim:api:idp:2.0:Attribute',
        'urn:hid:scim:api:idp:2.0:UserDevice'
      ],
      externalId: body.Username,
      groups: [
        {
          value: 'USG_CUST'
        }
      ],
      'urn:hid:scim:api:idp:2.0:UserAttribute': {
        attributes: [
          {
            name: 'ATR_STATUS',
            type: 'string',
            value: 'ACTIVE',
            readOnly: false
          },
          {
            name: 'ATR_CHAN',
            type: 'string',
            value: 'INTERNET',
            readOnly: false
          },
          {
            name: 'ATR_LOGIN',
            type: 'string',
            value: 'Password',
            readOnly: false
          }
        ]
      }
    };
    const url = config.hidCredentials.userEventLog;

    logHIDPayload(
      `createHidUser, userName: ${body.Username}`,
      url,
      `Body: body.ExternalID: ${requestBody.externalId}`,
      `Headers : auth: auth-Bearer`
    );

    const response = await axios.post(url, requestBody, {
      headers: {
        Authorization: `Bearer ${auth}`,
        'Content-Type': 'application/scim+json',
        ...tracingHeaders
      }
    });

    logHIDResponse('createHIDUSER- Create user first before password creation', url, '', {
      status: response.status,
      statusText: response.statusText,
      respHeaders: response.headers
    });

    await createUserPassword(body.Username, auth, body.password, tracingHeaders);
    updateStatistics(config.statistics.successUserCreation, {
      user: body.Username,
      date: new Date(),
      type: 'registration',
      platform: platform,
      success: true
    }).catch((e) =>
      logger.error(`err in update Statistics of functioName:createHidUser - err:${e.message}`)
    );
    return { message: 'Success' };
  } catch (e) {
    logHIDError(e, body?.Username || '', `CreateHIDUser`);
    logger.error(`FunctionName: CreateHIDUser - REGISTER ERROR - err:  ${e.message}`);
    updateStatistics(config.statistics.failedUserCreation, {
      user: body.Username,
      date: new Date(),
      type: 'registration',
      reason: 'CreateHIDUser - REGISTER ERROR',
      platform: platform,
      success: false
    }).catch((e) =>
      logger.error(`err in update Statistics of functioName:createHidUser - err:${e.message}`)
    );
    throw new InternalError(e.message);
  }
};

export const removeHidUser = async (userId: string, auth: string) => {
  try {
    logHIDPayload(
      'removeHIDUser',
      config.hidCredentials.deleteUser.replace('{{userId}}', userId),
      `HID-BODY: no body here`,
      `Headers: auth`
    );

    const resp = await axios.delete(
      config.hidCredentials.deleteUser.replace('{{userId}}', userId),
      {
        headers: { authorization: `Bearer ${auth}` }
      }
    );

    logHIDResponse('removeHidUser', `/v2/Users/{{${userId}}}`, '', {
      status: resp.status,
      headers: resp.headers
    });
    return resp;
  } catch (e) {
    logger.error(
      `functionName: removeHidUser - ERROR REGISTER- user: ${userId} - ERR: ${e.message}`
    );
    logHIDError(e.message, userId, 'removeHidUser');
  }
};

export const createT24User = async (
  body: any,
  authorization: string,
  tracingHeaders: any,
  platform: string,
  country?: string
) => {
  try {
    const data = {
      route: `admin/register/submit`,
      method: 'post',
      authorization,
      body: {
        Token: body.Token,
        OTP: body.OTP,
        Username: body.Username
      },
      country
    };

    logger.debug(
      `in case of Logger ENV = true will print data ->registerNewUser - dataSentToT24 : `,
      {
        route: `admin/register/submit`,
        auth: 'auth',
        bodyUserName: body.UserName,
        bodyOtp: '',
        bodyToken: ''
      }
    );

    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);

    const response = await prepareKafkaResponse(producerData);
    logger.debug(`FunctionName: crate24USer - KafkaResponce : `, response);

    return { message: 'Success' };
  } catch (e) {
    logger.error(
      `FunctionName: create24User - REGISTER ERROR -, User: ${body.Username}  ERROR: ${e.message}`
    );
    if (e.message === messages.authentication.conflict.en) {
      updateStatistics(config.statistics.failedUserCreation, {
        user: body.Username,
        date: new Date(),
        type: 'registration',
        reason: 'Username already taken',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:createT24User - err:${e.message}`)
      );
      throw new ConflictError();
    }
    if (e.message === messages.authentication.invalidOtp.en) {
      updateStatistics(config.statistics.failedUserCreation, {
        user: body.Username,
        date: new Date(),
        type: 'registration',
        reason: 'Invalid OTP',
        platform,
        success: false
      }).catch((e) =>
        logger.error(`err in update Statistics of functioName:createT24User - err:${e.message}`)
      );

      throw new ForbiddenError(messages.authentication.invalidOtp.en);
    }
    updateStatistics(config.statistics.failedUserCreation, {
      user: body.Username,
      date: new Date(),
      type: 'registration',
      reason: 'Create T24 User Failed',
      platform,
      success: false
    }).catch((e) =>
      logger.error(`err in update Statistics of functioName:createT24User - err:${e.message}`)
    );
    throw new InternalError(e.message);
  }
};

export const createUserPassword = async (
  username: string,
  auth: string,
  password: string,
  tracingHeaders: any
) => {
  try {
    const userId = await getUserId(username, auth, false, tracingHeaders);
    const body = {
      schemas: ['urn:hid:scim:api:idp:2.0:Authenticator'],
      policy: {
        value: 'AT_CUSTPW'
      },
      status: {
        status: 'ENABLED',
        expiryDate: moment().add(3, 'M').format('YYYY-MM-DDThh:mm:ss+00:00'),
        startDate: moment().subtract(1, 'days').format('YYYY-MM-DDThh:mm:ss+00:00')
      },
      owner: {
        value: userId
      },
      'urn:hid:scim:api:idp:2.0:Password': {
        username,
        password
      }
    };

    const url = config.hidCredentials.addPassword;

    logHIDPayload(
      `CreatePassword`,
      url,
      ` HIDBODY: USERNAME: ${username}, PASS: `,
      `Headers: willTimeoutAfter: ${config.promiseTimeout},  auth: Auth-Bearer Token`
    );

    const response = await axios.post(url, body, {
      timeout: config.promiseTimeout,
      headers: { 'Content-Type': 'application/scim+json', Authorization: `Bearer ${auth}` }
    });

    logHIDResponse('createHIDPassword', url, `UserName: ${username} `, {
      status: response.status,
      statusText: response.statusText,
      headers: response.headers
    });
  } catch (e) {
    logHIDError(e, username);
    logger.error(
      `FunctionName: Create-PASSWORD for USER: ${username}  -REGISTER ERROR- ERR:  ${e.message}`
    );
    throw new InternalError(e.message);
  }
};

export const requestOnboarding = async (
  body: {
    fullName: string;
    mobileNumber: string;
    productOfInterest: string;
  },
  tracingHeaders: any,
  platform: string
) => {
  try {
    const data = {
      topic: kafkaTopics.smtp,
      function: 'sendEmailService',
      body,
      template: 'newCustomerRequest'
    };
    await produce(data, tracingHeaders, false);

    updateStatistics('', {
      type: 'request',
      subType: 'newCustomerRequest',
      date: new Date(),
      microservice: 'idp',
      fullName: body.fullName,
      mobile: body.mobileNumber,
      requestDetail: body.productOfInterest,
      platform
    }).catch((e) => e.message);
    return { message: 'Success' };
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError();
  }
};

export const getListRegistrationCountries = async (language = 'en') => {
  try {
    return { result: registrationCountries[language] || registrationCountries['en'] };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.authentication.internalError.en);
  }
};
