import winston, { Logger, Logform } from 'winston';
import correlation from 'express-correlation-id';
import { environment } from '../config';
import { HIDPayLoad } from '../config';
import * as config from '../config';
import util from 'util';

class LoggerUtils {
  private static instance: Logger;

  private getLogger(): Logger {
    return winston.createLogger({
      level: environment === 'development' ? 'debug' : HIDPayLoad === 'true' ? 'debug' : 'info',
      format: winston.format.combine(
        winston.format((info) => {
          info.correlationId = correlation.getId() || '';
          return info;
        })(),
        winston.format.errors({ stack: true }),
        winston.format.timestamp(),
        winston.format.splat(),
        winston.format.printf(this.logTransform)
      ),
      transports: [new winston.transports.Console()],
      exitOnError: false
    });
  }

  static getInstance(): Logger {
    if (!LoggerUtils.instance) {
      const loggerUtils = new LoggerUtils();
      LoggerUtils.instance = loggerUtils.getLogger();
    }

    return LoggerUtils.instance;
  }

  private logTransform = (info: Logform.TransformableInfo): string => {
    if (HIDPayLoad === 'true') {
      const { level, message, timestamp, correlationId, ...rest } = info;

      let filteredRest: any = Object.fromEntries(Object.entries(rest));

      filteredRest = util.inspect(filteredRest, {
        depth: 2,
        breakLength: Infinity
      });
      filteredRest = filteredRest !== '{}' ? ` ${filteredRest}` : '';

      return `${timestamp} -${correlationId}- ${level}: ${message} ${filteredRest}`;
    } else {
      const { level, message, timestamp, correlationId } = info;
      return `${timestamp} -${correlationId}- ${level}: ${message} `;
    }
  };
}

const logger = LoggerUtils.getInstance();

const logHIDError = (error: any, user = 'NA', functionName?: string) => {
  if (error?.request?.host === config.hidCredentials.hostName) {
    const path = error?.request?.path || '';
    if (error?.response?.data?.error_description)
      logger.error(
        `HID Error: ${error?.response?.data?.error_description}, reason.code: ${error.response?.data?.hid_failure?.reason} , path: ${path}, user: ${user}, function: ${functionName}`
      );
    else if (error?.response?.data?.detail || error?.response?.data?.status)
      logger.error(
        `HID Error: ${error?.response?.data?.detail}, errorCode: ${error.response?.data?.errorCode} , path: ${path} , user: ${user}, function:  ${functionName}`
      );
    else console.log('function Name: ', functionName, { HIDErrorData: error?.response?.data });
  }
};
0;
const logHIDPayload = (
  functionName: any,
  path: any,
  bodyString?: any,
  headers?: any,
  ...rest: any
) => {
  if (HIDPayLoad === 'true') {
    logger.debug(
      `HID PAYLoad -> function: ${functionName},  path:  ${path},    ${bodyString},    ${headers} `
    );
  }
};

const logHIDResponse = (functionName: any, path: any, resutlString?: any, ...rest: any) => {
  if (HIDPayLoad === 'true') {
    logger.debug(
      `HID Response -> function: ${functionName},   path:  ${path} ,   result: ${resutlString}`,
      rest
    );
  }
};
export { Logger, logger, logHIDError, logHIDPayload, logHIDResponse };
