import { logger } from '../core/Logger';
import { InternalError } from '../core/ApiError';
import generateAdminToken from './adminToken';
import { registrationSms, blockedSms } from '../config';
import { produce } from '../kafka';
import { prepareKafkaResponse } from '../services/access/index';

export const sendSmsByCif = async (
  cif: string,
  registrationCode: string,
  type: string,
  tracingHeaders: any,
  country = 'EG'
) => {
  try {
    const auth = await generateAdminToken(tracingHeaders);
    let text: string;
    switch (type) {
      case 'bio':
        text = registrationSms.bio.en.replace('{activationCode}', registrationCode);
        break;
      case 'blockedLogin':
        text = blockedSms.blockedLogin.en;
        break;
      case 'blockedToken':
        text = blockedSms.blockedToken.en;
        break;
      default:
        text = registrationSms.device.en.replace('{activationCode}', registrationCode);
    }
    const data = {
      route: `admin/sendsms`,
      method: 'post',
      body: {
        Type: 'Cif',
        Key: cif,
        Text: text
      },
      country,
      authorization: `Bearer ${auth}`
    };
    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e);
  }
};
