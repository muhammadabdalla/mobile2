export interface CurrencyDetails {
  CountryCode: string;
  CurrencyCode: string;
  CurrencyNameEnglish: string;
  CurrencyNameArabic: string;
  CurrencyMultiplyDivider: string;
  CashBuyRate: number;
  CashSellRate: number;
  TransferBuyRate: number;
  TransferSellRate: number;
  LastUpdatedDate: string;
  LastUpdatedTime: string;
  Status: string;
}
