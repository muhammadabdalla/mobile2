import { Request } from 'express';

declare interface PublicRequest extends Request {
  apiKey: string;
}

declare interface RoleRequest extends PublicRequest {
  currentRoleCode: string;
}

declare interface ProtectedRequest extends RoleRequest {
  user: any;
  accessToken: string;
  accounts: [string];
  correlationId: () => string;
}

declare interface SubmitIssuance {
  Company: string;
  UserId: string;
  Pwd: string;
  transactionID: string;
  Customer: string;
  CDType: string;
  NumberOfCDs: number;
  FreshAmount: number;
  RENEWAL: string;
  CBEAmount: number;
  CBEDescription: number;
  ENDOWMENTCD: string;
  DonorID: string;
  DrawdownAccount: string;
  PrincipleAccount: string;
  IntrestAccount: string;
  ChargeAccount: string;
  AccountOfficer: string;
}
