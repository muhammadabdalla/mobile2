import express from 'express';
import { SuccessResponse } from '../../core/ApiResponse';
import asyncHandler from '../../helpers/asyncHandler';
import * as service from '../../services/investment';
import authenticate from '../../helpers/authenticate';
import { validate } from 'express-validation';
import schema from './schema';
import { ProtectedRequest } from 'app-request';
import tracingHeaders from '../../helpers/tracingHeaders';

const router = express.Router();

router.get(
  '/',
  authenticate(),
  validate(schema.listInvestment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getTwinListOfInvestment(
      req.user,
      (req.query.currency as string) || '',
      req.headers.authorization || '',
      tracingHeaders(req),
      req.headers['version-number'] || ''
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/mutualfund',
  authenticate(),
  validate(schema.listInvestment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getMutualFunds(
      req.user,
      String(req.query.currency || 'EGP'),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/cd/types',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getCdTypes(
      tracingHeaders(req),
      req?.query || false,
      req.headers['accept-language'] || 'en',
      req.headers['version-number'] || ''
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/cd/types/V2',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getCdTypesV2(
      tracingHeaders(req),
      req.headers.authorization || '',
      req?.user.cif,
      (req.query.currency as string) || '',
      req?.query || false,
      req.headers['accept-language'] || 'en'
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/cd/types/list',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getCdTypesList(
      tracingHeaders(req),
      req?.query || false,
      req.headers['accept-language'] || 'en'
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/cd/submit',
  authenticate(),
  validate(schema.submitIssuance),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.submitIssuance(
      {
        Company: '',
        UserId: '',
        Pwd: '',
        transactionID: '',
        Customer: req.user.cif,
        CDType: req.body.CDType,
        NumberOfCDs: req.body.numberOfCds,
        FreshAmount: req.body.freshAmount,
        RENEWAL: req.body.renewal,
        CBEAmount: req.body.CBEAmount,
        CBEDescription: req.body.CBEDescription,
        ENDOWMENTCD: req.body.endowmentCD,
        DonorID: '',
        DrawdownAccount: req.body.drawDownAccount,
        PrincipleAccount: req.body.principleAccount,
        IntrestAccount: req.body.interestAccount,
        ChargeAccount: req.body.chargeAccount,
        AccountOfficer: ''
      },
      req.user,
      req.headers.authorization || '',
      tracingHeaders(req),
      req.headers['version-number'] || ''
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/cd/issue',
  authenticate(),
  validate(schema.submitIssuance),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.issueCdAndAuth(
      {
        Company: '',
        UserId: '',
        Pwd: '',
        transactionID: '',
        Customer: req.user.cif,
        CDType: req.body.CDType,
        NumberOfCDs: req.body.numberOfCds,
        FreshAmount: req.body.freshAmount,
        RENEWAL: req.body.renewal,
        CBEAmount: req.body.CBEAmount,
        CBEDescription: req.body.CBEDescription,
        ENDOWMENTCD: req.body.endowmentCD,
        DonorID: '',
        DrawdownAccount: req.body.drawDownAccount,
        PrincipleAccount: req.body.principleAccount,
        IntrestAccount: req.body.interestAccount,
        ChargeAccount: req.body.chargeAccount,
        AccountOfficer: ''
      },
      req.user,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/cd/authorize',
  authenticate(),
  validate(schema.authorizeIssuance),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.authorizeIssuance(
      req.body.transactionID,
      req.headers.authorization || '',
      tracingHeaders(req),
      req.user.id
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/cd/cancel',
  authenticate(),
  validate(schema.cancelIssuance),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.cancelIssuance(
      req.body.transactionID,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/unauth',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getUnAuthCertificates(
      req.headers.authorization || '',
      req.user.cif,
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/treasury',
  authenticate(),
  validate(schema.listInvestment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getListTreasury(
      req.user,
      (req.query.currency as string) || '',
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/requestSecuredLoan',
  authenticate(),
  validate(schema.requestSecuredLoan),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.requestSecuredLoan(
      req.user.cif,
      req.user.id,
      req.user.phoneNumber || '',
      req.body.productDetails,
      String(req.headers.platform),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/topUpLoan',
  authenticate(),
  validate(schema.requestTopUpLoan),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.requestTopUpLoan(
      req.user.cif,
      req.user.id,
      req.user.phoneNumber || '',
      req.body.loanName
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/book/securedLoan',
  authenticate(),
  validate(schema.bookSecuredLoan),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.bookSecuredLoan(
      req.headers.authorization || '',
      req.user.cif,
      req.user.id,
      req.body,
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/cd/sourceOfFund',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = service.getCdSourceOfFund(tracingHeaders(req));
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/redemptionTable',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = service.getRedemptionTable(req.headers['accept-language'] || 'en');
    new SuccessResponse('Success', result).send(res);
  })
);

export default router;
