import Joi from 'joi';

export default {
  listInvestment: {
    query: Joi.object({
      currency: Joi.string().optional().allow('')
    })
  },
  submitIssuance: {
    body: Joi.object({
      CDType: Joi.string().required(),
      numberOfCds: Joi.number().required(),
      freshAmount: Joi.number().valid(0).required(),
      renewal: Joi.string().required(),
      CBEAmount: Joi.number()
        .required()
        .valid(Joi.ref('numberOfCds', { adjust: (value) => value * 1000 })),
      CBEDescription: Joi.number().valid(1, 2, 3, 4, 5).required(),
      endowmentCD: Joi.string().required(),
      drawDownAccount: Joi.string().required(),
      principleAccount: Joi.string().required(),
      interestAccount: Joi.string().required(),
      chargeAccount: Joi.string().required()
    })
  },
  authorizeIssuance: {
    body: Joi.object({
      transactionID: Joi.string().required()
    })
  },
  cancelIssuance: {
    body: Joi.object({
      transactionID: Joi.string().required()
    })
  },
  requestSecuredLoan: {
    body: Joi.object({
      productDetails: Joi.string().optional()
    })
  },
  requestTopUpLoan: {
    body: Joi.object({
      loanName: Joi.string().required()
    })
  },
  bookSecuredLoan: {
    body: Joi.object({
      LoanType: Joi.string().required(),
      Amount: Joi.number().required(),
      DisbursmentAccount: Joi.string().required(),
      InstLiqAccount: Joi.string().required(),
      Currency: Joi.string().required(),
      Tenor: Joi.number().required(),
      ContractReference: Joi.string().required(),
      otp: Joi.string().required()
    })
  }
};
