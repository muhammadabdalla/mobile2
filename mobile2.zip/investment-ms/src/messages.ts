export default {
  accounts: {
    notRegistered: {
      en: 'Account not registered'
    },
    timeout: {
      en: 'Request Timeout'
    },
    missingValue: {
      en: 'Missing Value'
    },
    internalError: {
      en: 'Internal Server Error'
    },
    notFound: {
      en: 'Account Not Found'
    },
    transferAccount: {
      en: 'Invalid credit or debit account'
    },
    overDraftAccount: {
      en: 'Draft account not allowed to transfer'
    }
  },
  authorization: {
    notFound: {
      en: 'Authorization must be provided'
    },
    invalid: {
      en: 'Invalid token'
    }
  },
  securedLoan: {
    iScoreRejection: {
      en: 'iScore Rejection'
    }
  },
  CD: {
    isCancellAllowed: {
      en: 'Only New Contracts Allowed.'
    },
    IssuanceNotValidNow: {
      en: 'INVALID FUNCTION FOR END.OF.DAY'
    }
  }
};
