import * as service from '../../../src/services/investment';
import {
  authorizeCD,
  defaultResponse,
  cdTypesResult,
  investmentResult,
  mockKafkaSuccess,
  mutualResult
} from '../../mocks/kafka';

// describe('Get list of investments', () => {    un comment
//   beforeEach(() => {
//     jest.clearAllMocks();
//   });

//   it('Should return success', async () => {
//     mockKafkaSuccess();
//     const response = await service.getListOfInvestment(10100111, 'EGP', '', null);
//     expect(response).toStrictEqual(investmentResult);
//   });
// });

// describe('Get list of mutual funds', () => {
//   beforeEach(() => {
//     jest.clearAllMocks();
//   });

//   it('Should return success', async () => {
//     mockKafkaSuccess();
//     const response = await service.getMutualFunds(10100111, 'EGP', '', null);
//     expect(response).toStrictEqual(mutualResult);
//   });
// });

describe('Get cd types', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess();
    const response = await service.getCdTypes('', {}, 'en', '1');
    expect(response).toStrictEqual(cdTypesResult);
  });
});

describe('Submit issuance', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess();
    const response = await service.submitIssuance(
      {
        Company: '',
        UserId: '',
        Pwd: '',
        transactionID: '',
        Customer: '123123',
        CDType: '036-01-1000-01',
        NumberOfCDs: 1,
        FreshAmount: 1,
        RENEWAL: 'YES',
        CBEAmount: 1,
        CBEDescription: 1,
        ENDOWMENTCD: '',
        DonorID: '',
        DrawdownAccount: '',
        PrincipleAccount: '',
        IntrestAccount: '',
        ChargeAccount: '',
        AccountOfficer: ''
      },
      {},
      '',
      '',
      true
    );
    expect(response).toStrictEqual(authorizeCD);
  });
});

describe('Authorize issuance', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess();
    const response = await service.authorizeIssuance('LD1111111111', '', '', 'test1');
    expect(response).toStrictEqual(defaultResponse);
  });
});

describe('cancel issuance', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess();
    const response = await service.cancelIssuance('transaction', '', '');
    expect(response).toStrictEqual(defaultResponse);
  });
});
