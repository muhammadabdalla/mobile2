import * as kafka from '../../src/kafka';

export const produceResult = {
  greenPearls: {
    value:
      '{"error": false, "message": { "Data": [{"ID": "MM2030211786", "Currency": "USD", "Amount": 1000}] }}'
  },
  timeDeposit: {
    value:
      '{"error": false, "message": { "Data": [{"ID": "MM2030211787", "Currency": "EGP", "Amount": 15.65}] }}'
  },
  certificates: {
    value:
      '{"error": false, "message": { "Data": [{"ID": "MM2030211787", "Currency": "EGP", "LDAmount": 1000}] }}'
  },
  conversion: {
    value:
      '{"error": false, "message": { "Data": [{"CurrencyCode": "USD", "TransferBuyRate": 15.65}] }}'
  },
  mutualFund: {
    value:
      '{"error": false, "message": { "Data": [{"FundId": "800009-003", "Currency": "EGP", "InitialPrice": 150, "Units": 100, "Price": 200, "MarketValue": 20000, "FundName": "Short.name 800009-003" }] }}'
  },
  defaultValue: {
    value: '{"error": false, "message": { "TransactionId": 12345 }}'
  },
  cdTypes: {
    value:
      '{"error": false, "message": { "Data": [{ "Type": "Fixed" }, { "Type": "Discounted" }, { "Type": "Floating" }] }}'
  },
  submitTypes: {
    value:
      '{"error": false, "message": { "Data": {"Status": "true", "TransactionId": "LD2129443071", "InterestRate": 40 }}}'
  },
  cdData: {
    value:
      '{"error": false, "message": { "Data": [{"Status": "true","LDType":"036-01-1000-01DS", "LDAmount": "1000", "InterestAccount": "1010011160010201", "ChargeAccount": "1010011160010201", "Renewal": "NO" }]}}'
  }
};

export const cdTypesResult = [
  {
    Type: 'Fixed',
    firstTimeMin: 5000,
    min: 1000,
    multiplyInterest: true,
    upFrontView: false
  },
  {
    Type: 'Discounted'
  }
];

export const authorizeCD = {
  Status: 'true',
  TransactionId: 'LD2129443071',
  Message: '',
  InterestRate: 40
};

export const defaultResponse = {
  message: 'Success'
};

export const investmentResult = {
  investments: [
    {
      data: [
        {
          ID: 'MM2030211786',
          Currency: 'USD',
          Amount: 1000
        },
        {
          ID: 'MM2030211787',
          Currency: 'EGP',
          Amount: 15.65
        }
      ],
      type: 'timeDeposit',
      total: 79.55,
      currency: 'EGP'
    },
    {
      data: [
        {
          ID: 'MM2030211787',
          Currency: 'EGP',
          LDAmount: 1000,
          Amount: 1000
        }
      ],
      type: 'certificates',
      total: 1000,
      currency: 'EGP'
    }
  ]
};

export const mutualResult = {
  MutualFunds: [
    {
      FundName: 'Short.name 800009-003',
      Currency: 'EGP',
      Price: 200,
      Units: 100,
      InitialPrice: 15000,
      MarketValue: 20000,
      Frequency: 33.33,
      details: [
        {
          FundId: '800009-003',
          FundName: 'Short.name 800009-003',
          Currency: 'EGP',
          InitialPrice: 150,
          MarketValue: 20000,
          Units: 100,
          Price: 200
        }
      ],
      FundId: '800009-003',
      profit: 5000
    }
  ],
  currency: 'EGP',
  total: 20000
};

export const mockKafkaSuccess = () => {
  jest.spyOn(kafka, 'createConsumer');
  const mock = jest.spyOn(kafka, 'produce');
  mock.mockImplementation(async (data) => {
    switch (data.route) {
      case 'mm/greenpearl/customer/10100111':
        return Promise.resolve(produceResult.greenPearls);
      case 'mm/timedeposit/customer/10100111':
        return Promise.resolve(produceResult.timeDeposit);
      case 'ld/certificate/customer/10100111':
        return Promise.resolve(produceResult.certificates);
      case 'rates/exchange/EGP':
        return Promise.resolve(produceResult.conversion);
      case 'securities/mutualfund/customer/10100111':
        return Promise.resolve(produceResult.mutualFund);
      case `ld/cd/types`:
        return Promise.resolve(produceResult.cdTypes);
      case `ld/cd/issuance/entry/input`:
        return Promise.resolve(produceResult.submitTypes);
      case `ld/cd/submit/authorize`:
        return Promise.resolve(produceResult.submitTypes);
      case `ld/certificate/LD1111111111`:
        return Promise.resolve(produceResult.cdData);
      case `ld/cd/submit/cancel`:
        return Promise.resolve(produceResult.submitTypes);
    }
  });
};
