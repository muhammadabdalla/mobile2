import mongoose from 'mongoose';

const model = new mongoose.Schema(
  {
    successLogin: {
      type: Number,
      default: 0
    },
    failedLogin: {
      type: Number,
      default: 0
    },
    ownTransferSuccess: {
      type: Number,
      default: 0
    },
    ownTransferFail: {
      type: Number,
      default: 0
    },
    internalTransferSuccess: {
      type: Number,
      default: 0
    },
    internalTransferFail: {
      type: Number,
      default: 0
    },
    externalTransferSuccess: {
      type: Number,
      default: 0
    },
    externalTransferFail: {
      type: Number,
      default: 0
    },
    successUserCreation: {
      type: Number,
      default: 0
    },
    failedCreditPayment: {
      type: Number,
      default: 0
    },
    successCreditPayment: {
      type: Number,
      default: 0
    },
    timeoutTransfers: {
      type: Number,
      default: 0
    },
    successPayments: {
      type: Number,
      default: 0
    },
    failedPayments: {
      type: Number,
      default: 0
    },
    t24LoginFailure: {
      type: Number,
      default: 0
    },
    timeoutCreditPayment: {
      type: Number,
      default: 0
    },
    inactiveUserLoginFailure: {
      type: Number,
      default: 0
    },
    duplicateLoginFailure: {
      type: Number,
      default: 0
    },
    expiredLoginFailure: {
      type: Number,
      default: 0
    },
    notRegisteredFailure: {
      type: Number,
      default: 0
    },
    suspendedLoginFailure: {
      type: Number,
      default: 0
    },
    invalidCredentialsFailure: {
      type: Number,
      default: 0
    }
  },
  { timestamps: true }
);
model.index({ createdAt: 1 });
export default mongoose.model('statistics', model);
