import { logger } from '../core/Logger';
import moment from 'moment-timezone';
import { CronJob } from 'cron';
import StatisticsModel from '../model/model';
import { IncomingWebhook } from 'ms-teams-webhook';
import { teamsUrl, kafkaTopics, defaultStatisticsValue, elasticsearch } from '../config';
import { getPartitionId } from '../kafka/consumer';
import { connectElastic } from '../elasticsearch';
let keys: any;

export const handleStatistics = async (kafkaData: string) => {
  const data = JSON.parse(kafkaData);
  try {
    const startDate = new Date(moment(data.date).tz('Africa/Cairo').startOf('day').format());
    const endDate = new Date(moment(data.date).tz('Africa/Cairo').endOf('day').format());
    await StatisticsModel.findOneAndUpdate(
      { createdAt: { $gte: startDate, $lte: endDate } },
      { $inc: { [data.updateValue]: 1 } },
      { upsert: true, useFindAndModify: false }
    );
    logger.info('Statistics updated', { correlationId: data.correlationId, status: 200 });
  } catch (e) {
    logger.error('Internal error', {
      correlationId: data.correlationId,
      status: 500,
      error: e.message
    });
  }
};

export const sendStatistics = async () => {
  try {
    const job = new CronJob(
      '0 0 */1 * * *',
      async () => {
        const partitionId = await getPartitionId(kafkaTopics.statistics);
        if (partitionId === 0) {
          const facts: any = [];
          let sections: any;
          const startDate = new Date(
            moment().tz('Africa/Cairo').subtract(30, 'minutes').startOf('day').format()
          );
          const endDate = new Date(
            moment().tz('Africa/Cairo').subtract(30, 'minutes').endOf('day').format()
          );
          const record = await StatisticsModel.findOne(
            { createdAt: { $gte: startDate, $lte: endDate } },
            { createdAt: 0, updatedAt: 0, _id: 0, __v: 0 }
          )
            .sort({
              _id: -1
            })
            .lean();
          if (record) {
            keys = Object.keys(record);
            keys.forEach((key: any) => {
              facts.push({
                name: key,
                value: record[key]
              });
            });
            sections = [
              {
                facts
              }
            ];
          } else {
            sections = [
              {
                text: defaultStatisticsValue
              }
            ];
          }
          const webhook = new IncomingWebhook(teamsUrl);
          await webhook.send(
            JSON.stringify({
              '@type': 'MessageCard',
              '@context': 'https://schema.org/extensions',
              themeColor: '0078D7',
              title: 'Hourly statistics',
              summary: 'Hourly statistics',
              sections
            })
          );
        }
      },
      null,
      true,
      'Africa/Cairo'
    );
    job.start();
  } catch (e) {
    logger.error(e.message);
  }
};

export const handleElasticData = async (kafkaData: string) => {
  const data = JSON.parse(kafkaData);
  try {
    const client = await connectElastic();
    data.kibanaInfo.correlationId = data.correlationId || '';
    await client.index({
      index: elasticsearch.alias,
      body: data.kibanaInfo
    });
    logger.info('Kibana statistics updated', { correlationId: data.correlationId, status: 200 });
  } catch (e) {
    logger.error('Kibana internal error', {
      correlationId: data.correlationId,
      status: 500,
      error: e.message
    });
    logger.error(e.message);
  }
};
