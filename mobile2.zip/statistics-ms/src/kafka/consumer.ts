import { AssignerProtocol, Consumer, Kafka } from 'kafkajs';
import { kafkaOptions, kafkaTopics } from '../config';
import { logger } from '../core/Logger';
import { handleElasticData, handleStatistics, sendStatistics } from '../services';

let consumer: Consumer;
let client: any;
let interval: number;
let memberId: string;
export const connector = () => {
  return new Kafka({
    clientId: kafkaOptions.clientId,
    brokers: kafkaOptions.hosts,
    connectionTimeout: kafkaOptions.connectionTimeout,
    requestTimeout: kafkaOptions.requestTimeout,
    retry: {
      initialRetryTime: kafkaOptions.initialRetryTime,
      retries: kafkaOptions.retries
    }
  });
};

export const createKafkaClient = () => {
  if (client) return client;
  return new Kafka({
    clientId: kafkaOptions.clientId,
    brokers: kafkaOptions.hosts,
    connectionTimeout: kafkaOptions.connectionTimeout,
    requestTimeout: kafkaOptions.requestTimeout,
    retry: {
      initialRetryTime: kafkaOptions.initialRetryTime,
      retries: kafkaOptions.retries
    }
  });
};

export const createConsumer = async () => {
  try {
    client = createKafkaClient();
    consumer = await client.consumer(kafkaOptions.consumerPolicy);
    await consumer.connect();
    await consumer.subscribe({ topic: kafkaTopics.statistics });
    await consumer.subscribe({ topic: kafkaTopics.kibana });
    consumer.on(consumer.events.GROUP_JOIN, ({ timestamp, payload }) => {
      interval = timestamp;
      memberId = payload.memberId;
    });
    consumer.on(consumer.events.HEARTBEAT, ({ timestamp, payload }) => {
      interval = timestamp;
      memberId = payload.memberId;
    });
    sendStatistics();
    await consumer.run({
      eachMessage: async ({ message, topic }) => {
        if (!message.headers || !message.value) {
          logger.error('Missing required fields');
        } else {
          if (topic === kafkaTopics.kibana) handleElasticData(message.value.toString());
          else handleStatistics(message.value.toString());
        }
      }
    });
  } catch (e) {
    logger.debug(e.message);
  }
};

export const getHeartbeatTime = async () => {
  return {
    consumer,
    interval,
    memberId
  };
};

export const getPartitionId = async (topic: string) => {
  try {
    let partitionId: any;
    const consumerGroup = await consumer.describeGroup();
    const member = consumerGroup.members.find((member) => member.memberId === memberId);
    if (member) {
      const memberAssignment =
        AssignerProtocol.MemberAssignment.decode(member.memberAssignment)?.assignment || {};
      if (memberAssignment[topic]?.length) {
        partitionId = Math.min(...memberAssignment[topic]);
      }
    }
    return partitionId;
  } catch (e) {
    logger.debug(e.message);
    return null;
  }
};
