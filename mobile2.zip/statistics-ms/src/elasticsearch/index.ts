import { logger } from '../core/Logger';
import { Client } from '@elastic/elasticsearch';
import * as config from '../config';
let client: any;

export const connectElastic = () => {
  try {
    if (client) return client;
    client = new Client({
      node: config.elasticsearch.url,
      auth: { username: config.elasticsearch.username, password: config.elasticsearch.password },
      ssl: {
        rejectUnauthorized: false
      }
    });
  } catch (e) {
    logger.error(e);
    throw e;
  }
};

export const disconnectElastic = async () => {
  await client.close();
  client = null;
};

export const policyManagement = async () => {
  try {
    const policy = await getPolicy();
    if (!policy) {
      await client.ilm.putLifecycle({
        policy: config.elasticsearch.policyName,
        body: config.elasticsearch.policyConfiguration
      });
    }
  } catch (e) {
    logger.error(e.message);
  }
};

export const createdIndexTemplate = async () => {
  try {
    await policyManagement();
    const template = await getTemplate();
    if (!template) {
      await client.indices.putIndexTemplate({
        name: config.elasticsearch.templateName,
        body: {
          index_patterns: config.elasticsearch.pattern,
          template: config.elasticsearch.templateConfiguration
        }
      });
    }
  } catch (e) {
    logger.error(e.message);
  }
};

export const createIndex = async () => {
  try {
    const client = connectElastic();
    const index = await getIndex();
    if (!Object.keys(index.body).length) {
      await createdIndexTemplate();
      await client.indices.create({
        index: config.elasticsearch.indexName
      });
      await createAlias();
    }
  } catch (e) {
    logger.error(e.message);
  }
};

export const createAlias = async () => {
  try {
    return client.indices.putAlias({
      index: config.elasticsearch.pattern,
      name: config.elasticsearch.alias
    });
  } catch (e) {
    logger.error(e.message);
  }
};

export const getTemplate = async () => {
  try {
    return await client.indices.getIndexTemplate({
      name: config.elasticsearch.templateName
    });
  } catch (e) {
    return false;
  }
};

export const getIndex = async () => {
  try {
    return await client.indices.get({
      index: config.elasticsearch.pattern[0]
    });
  } catch (e) {
    return false;
  }
};

export const getPolicy = async () => {
  try {
    return await client.ilm.getLifecycle({
      policy: config.elasticsearch.policyName
    });
  } catch (e) {
    return false;
  }
};
