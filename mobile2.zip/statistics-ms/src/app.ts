import express from 'express';
import { logger } from './core/Logger';
import cors from 'cors';
import helmet from 'helmet';
import { corsUrl } from './config';
import heartbeat from './health';
import { connect } from './database';
import { createConsumer } from './kafka/consumer';
import { connectElastic, createIndex, disconnectElastic } from './elasticsearch';

process.on('uncaughtException', (e) => {
  logger.error(e);
});

createConsumer().then();
connectElastic();
createIndex().catch((e) => logger.error(e.message));

const app = express();

// Security
app.use(helmet());

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true, parameterLimit: 50000 }));
app.use(cors({ origin: corsUrl, optionsSuccessStatus: 200 }));

connect();

process.on('SIGINT', async () => {
  // await disconnect();
  await disconnectElastic();
  process.exit(1);
});

app.use('/health', heartbeat);

export default app;
