// Mapper for environment variables
export const environment = process.env.NODE_ENV;
export const port = process.env.PORT;

export const corsUrl = process.env.CORS_URL;

export const kafkaOptions = {
  clientId: process.env.KAFKA_CLIENT_ID || '',
  hosts: process.env.KAFKA_HOSTS?.split(',') || [],
  connectionTimeout: parseInt(process.env.KAFKA_CONNECTION_TIMEOUT || '3000'),
  requestTimeout: parseInt(process.env.KAFKA_REQUEST_TIMEOUT || '25000'),
  initialRetryTime: parseInt(process.env.KAFKA_INITIAL_RETRY_TIME || '0'),
  retries: parseInt(process.env.KAFKA_RETRIES || '0'),
  producerPolicy: {
    allowAutoTopicCreation: true
  },
  consumerPolicy: {
    groupId: process.env.CONSUMER_GROUP_ID || 'statistics-connector-ms',
    allowAutoTopicCreation: true,
    sessionTimeout: Number(process.env.CONSUMER_SESSION_TIMEOUT || '30000'),
    heartbeatInterval: Number(process.env.CONSUMER_HEART_BEAT || '3000'),
    retry: {
      retries: parseInt(process.env.KAFKA_RETRIES || '0')
    }
  }
};

export const kafkaTopics = {
  statistics: 'statistics',
  kibana: 'kibanastatistics'
};

export const mongoConfig = {
  url: process.env.DB_URL || ''
};

export const teamsUrl = String(process.env.TEAMS_URL || '');

export const defaultStatisticsValue = 'No statistics found at the moment';

export const elasticsearch = {
  url: process.env.ELASTIC_URL || 'http://localhost:9200',
  username: process.env.ELASTIC_USERNAME || '',
  password: process.env.ELASTIC_PASSWORD || '',
  policyName: 'statistics_policy',
  indexName: 'statistics-000001',
  alias: 'statistics',
  pattern: ['statistics-*'],
  templateName: 'statistics_template',
  policyConfiguration: {
    policy: {
      phases: {
        hot: {
          actions: {
            rollover: {
              max_primary_shard_size: '50GB',
              max_age: '30d'
            }
          }
        },
        delete: {
          min_age: '731d',
          actions: {
            delete: {}
          }
        }
      }
    }
  },
  templateConfiguration: {
    settings: {
      number_of_shards: 5,
      number_of_replicas: 1,
      'index.lifecycle.name': 'statistics_policy',
      'index.lifecycle.rollover_alias': 'statistics'
    }
  }
};
