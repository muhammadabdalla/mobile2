// Mapper for environment variables
import path from 'path';

export const environment = process.env.NODE_ENV;
export const port = process.env.PORT;

export const corsUrl = process.env.CORS_URL;

export const kafkaOptions = {
  clientId: process.env.KAFKA_CLIENT_ID || '',
  hosts: process.env.KAFKA_HOSTS?.split(',') || [],
  connectionTimeout: parseInt(process.env.KAFKA_CONNECTION_TIMEOUT || '3000'),
  requestTimeout: parseInt(process.env.KAFKA_REQUEST_TIMEOUT || '25000'),
  initialRetryTime: parseInt(process.env.KAFKA_INITIAL_RETRY_TIME || '0'),
  retries: parseInt(process.env.KAFKA_RETRIES || '0'),
  producerPolicy: {
    allowAutoTopicCreation: true
  },
  consumerPolicy: {
    groupId: process.env.CONSUMER_GROUP_ID || 'smtp-ms',
    allowAutoTopicCreation: true,
    sessionTimeout: Number(process.env.CONSUMER_SESSION_TIMEOUT || '30000'),
    heartbeatInterval: Number(process.env.CONSUMER_HEART_BEAT || '3000'),
    retry: {
      retries: parseInt(process.env.KAFKA_RETRIES || '0')
    }
  },
  numberOfPartitions: Number(process.env.KAFKA_PARTITION_NUMBER || '3')
};

export const kafkaTopics = {
  smtp: 'smtp'
};

export const FILENET_BASE_URL = String(process.env.FILENET_BASE_URL || '');

export const axiosTimeOut = parseInt(process.env.AXIOS_TIMEOUT || '25000');

export const smtpCredentials = {
  username: process.env.SMTP_USERNAME || '',
  password: process.env.SMTP_PASSWORD || '',
  host: process.env.SMTP_HOST || '',
  port: process.env.SMTP_PORT || '',
  email: {
    from: process.env.SMTP_EMAIL_FROM || 'Mobile banking<SA-MobApp-01@aaib.com>',
    to: process.env.SMTP_EMAIL_TO || '',
    toLeads: process.env.SMTP_EMAIL_TO_LEADS || '',
    toRequests: process.env.SMTP_EMAIL_TO_REQUESTS || ''
  }
};

export const firebaseConfig = {
  pathToServiceAccount: process.env.FIREBASE_SERVICE_ACCOUNT_PATH || ''
};

export type EmailTemplate = {
  template: string;
  subject: string;
  attachments: Array<any>;
  email: string;
};

export const emailTemplates: Record<string, EmailTemplate> = {
  mailbox: {
    template: path.join(__dirname, '../emails/mailbox.pug'),
    subject: 'Message from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      }
    ],
    email: smtpCredentials.email.toRequests
  },
  loan: {
    template: path.join(__dirname, '../emails/loan.pug'),
    subject: 'Loan request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'loan_1.png',
        path: path.join(__dirname, '../images/Loan_1.png'),
        cid: 'Loan_1'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  topUpLoan: {
    template: path.join(__dirname, '../emails/topUpLoan.pug'),
    subject: 'Top up loan request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'loan_1.png',
        path: path.join(__dirname, '../images/Loan_1.png'),
        cid: 'Loan_1'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  creditCard: {
    template: path.join(__dirname, '../emails/creditCard.pug'),
    subject: 'Credit card request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'cc.png',
        path: path.join(__dirname, '../images/cc.png'),
        cid: 'cc'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  debitCard: {
    template: path.join(__dirname, '../emails/debitCard.pug'),
    subject: 'Debit card request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'cc.png',
        path: path.join(__dirname, '../images/cc.png'),
        cid: 'cc'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  newCustomerRequest: {
    template: path.join(__dirname, '../emails/newCustomerRequest.pug'),
    subject: 'New customer request',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'cc.png',
        path: path.join(__dirname, '../images/cc.png'),
        cid: 'cc'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  requestSecuredLoan: {
    template: path.join(__dirname, '../emails/requestSecuredLoan.pug'),
    subject: 'Secured loan request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'rectangle.png',
        path: path.join(__dirname, '../images/rectangle.png'),
        cid: 'rectangle'
      },
      {
        filename: 'investment.png',
        path: path.join(__dirname, '../images/investment.png'),
        cid: 'investment'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  requestSecuredLoanWithCD: {
    template: path.join(__dirname, '../emails/requestSecuredLoanWithCD.pug'),
    subject: 'Secured loan request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'rectangle.png',
        path: path.join(__dirname, '../images/rectangle.png'),
        cid: 'rectangle'
      },
      {
        filename: 'investment.png',
        path: path.join(__dirname, '../images/investment.png'),
        cid: 'investment'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  requestPayrollAdvance: {
    template: path.join(__dirname, '../emails/requestPayrollAdvance.pug'),
    subject: 'Advanced salary request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'rectangle.png',
        path: path.join(__dirname, '../images/rectangle.png'),
        cid: 'rectangle'
      },
      {
        filename: 'salary.png',
        path: path.join(__dirname, '../images/salary.png'),
        cid: 'salary'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  replaceCreditCard: {
    template: path.join(__dirname, '../emails/replaceCreditCard.pug'),
    subject: 'Credit card replacement for user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'cc.png',
        path: path.join(__dirname, '../images/cc.png'),
        cid: 'cc'
      }
    ],
    email: smtpCredentials.email.toRequests
  },
  replaceDebitCard: {
    template: path.join(__dirname, '../emails/replaceDebitCard.pug'),
    subject: 'Debit card replacement for user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'cc.png',
        path: path.join(__dirname, '../images/cc.png'),
        cid: 'cc'
      }
    ],
    email: smtpCredentials.email.toRequests
  },
  cd: {
    template: path.join(__dirname, '../emails/cd.pug'),
    subject: 'CD request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'loan_1.png',
        path: path.join(__dirname, '../images/Loan_1.png'),
        cid: 'Loan_1'
      }
    ],
    email: smtpCredentials.email.toLeads
  },
  requestUAEAccount: {
    template: path.join(__dirname, '../emails/requestUAEAccount.pug'),
    subject: 'New UAE Account request from user {cif}',
    attachments: [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: 'loan_1.png',
        path: path.join(__dirname, '../images/Loan_1.png'),
        cid: 'Loan_1'
      }
    ],
    email: smtpCredentials.email.toLeads
  }
};
