import { logger } from '../core/Logger';
import * as config from '../config';
import nodemailer from 'nodemailer';
import pug from 'pug';
import * as xlsx from 'xlsx';
import fs from 'fs';
import path from 'path';
import * as firebaseService from './firebase-cloud-messaging-service';
import axios from 'axios';
import qpdf from 'node-qpdf2';
import { createProducer } from '../kafka/producer';
import { CompressionTypes, ProducerRecord } from 'kafkajs';
import wkhtmltopdf from 'wkhtmltopdf';
import { v4 as uuidv4 } from 'uuid';
import { ESendStatement } from '../helpers/enums/sendStatementEnum';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const pdf2base64 = require('pdf-to-base64');
wkhtmltopdf.shell = '/bin/sh';

export const sendEmailService = async (message: any, correlationId: string) => {
  try {
    const data = JSON.parse(message);
    if (!data.template) data.template = 'loan';
    // @ts-ignore
    const templateConfig = config.emailTemplates[data.template];
    const fn = pug.compileFile(templateConfig.template);
    const html = fn({
      ...data.body,
      cif: data.cif
    });
    const transporter = nodemailer.createTransport({
      host: config.smtpCredentials.host,
      port: Number(config.smtpCredentials.port),
      ...(config.smtpCredentials.username &&
        config.smtpCredentials.password && {
          auth: {
            user: config.smtpCredentials.username,
            pass: config.smtpCredentials.password
          }
        }),
      tls: { rejectUnauthorized: false }
    });
    await transporter.sendMail({
      from: config.smtpCredentials.email.from,
      to: templateConfig.email,
      subject: templateConfig.subject.replace('{cif}', data.cif),
      attachments: templateConfig.attachments,
      html
    });
    logger.info('Success send email', {
      correlationId,
      status: 200
    });
  } catch (e) {
    logger.error('error in sending email', {
      correlationId,
      status: 500
    });

    logger.error(e.message);
    return null;
  }
};

export const generateTransferReceipt = async (
  message: any,
  correlationId: string,
  kafkaHeaders: { replyTopic: string; partitionReply: number }
) => {
  const kafkaData = JSON.parse(message);
  const randFileName = uuidv4();
  const filePath = path.join(__dirname, `../../${randFileName}.pdf`);

  const fn = pug.compileFile(path.join(__dirname, `../../emails/${kafkaData.template}.pug`));

  const html = fn({
    ...kafkaData.body,
    cif: kafkaData.cif
  });

  wkhtmltopdf.shell = '/bin/sh';

  try {
    // Generate PDF from html
    wkhtmltopdf(
      html,
      { output: filePath, ignore: [/QFont::setPixelSize/] },
      async (err, stream) => {
        if (err) {
          console.log(err);
        }
        // do whatever with the stream
        if (stream) {
          if (fs.existsSync(filePath)) {
            // ...
            console.log('File Exists');

            const base64String = await pdf2base64(filePath);

            console.log(base64String);
            // Generate response
            const producer = await createProducer();
            const producerOptions = getPDFandExcelProducerOptions(
              kafkaHeaders,
              base64String,
              kafkaData.body.name,
              correlationId
            );
            await producer.send(producerOptions);
            logger.info('Success in generating transfer receipt', { correlationId, status: 200 });
          }
        }
      }
    );
  } catch (e) {
    console.log(e);
    logger.error(e.message, { correlationId, status: 500 });
  } finally {
    fs.unlinkSync(filePath);
  }
};

export const generateExcelTable = async (
  message: any,
  correlationId: string,
  kafkaHeaders: { replyTopic: string; partitionReply: number }
) => {
  const kafkaData = JSON.parse(message);
  try {
    const newWB = xlsx.utils.book_new();
    const newWS = xlsx.utils.json_to_sheet(kafkaData.body.data);
    xlsx.utils.book_append_sheet(newWB, newWS, kafkaData.body.columnName);
    xlsx.writeFile(newWB, kafkaData.body.name);
    const filePath = path.join(__dirname, `../../${kafkaData.body.name}`);

    //for web, return the base64 string, for mobile send email instead
    if (kafkaData.body.isWeb) {
      const bitmap = fs.readFileSync(filePath);
      const base64Excel = bitmap.toString('base64');
      const producer = await createProducer();
      const producerOptions = getPDFandExcelProducerOptions(
        kafkaHeaders,
        base64Excel,
        kafkaData.body.name,
        correlationId
      );
      await producer.send(producerOptions);
    } else {
      const sentStatementEmailBody =
        kafkaData.body.sentStatementEmailBody || ESendStatement.DEFAULT_EMAIL_BODY;
      const fn = pug.compileFile(path.join(__dirname, '../../emails/statement.pug'));
      const html = fn({ sentStatementEmailBody });
      const attachments = [
        {
          filename: kafkaData.body.name,
          path: filePath,
          cid: kafkaData.body.name
        },
        {
          filename: 'main_1.png',
          path: path.join(__dirname, '../../images/main_1.png'),
          cid: 'main_1'
        }
      ];
      await sendFileEmail(
        kafkaData.body.email,
        ESendStatement.EMAIL_SUBJECT,
        attachments,
        correlationId,
        html
      );
    }

    fs.unlinkSync(filePath);
    logger.info(`Success in creating excel table ${kafkaData.body.email}`, {
      correlationId,
      status: 200
    });
  } catch (e) {
    logger.error(e.message, { correlationId, status: 500 });
    fs.unlinkSync(path.join(__dirname, `../../${kafkaData.body.name}`));
  }
};

export const generatePDFFTable = async (
  message: any,
  correlationId: string,
  kafkaHeaders: { replyTopic: string; partitionReply: number }
) => {
  const kafkaData = JSON.parse(message);
  try {
    const kafkaData = JSON.parse(message);
    const fn = pug.compileFile(path.join(__dirname, '../../emails/index.pug'));
    const html = fn({
      accountNumber: kafkaData.body.accountNumber,
      historyStartDate: kafkaData.body.fromDate,
      historyEndDate: kafkaData.body.toDate,
      data: kafkaData.body.data
    });
    const randFileName = uuidv4();
    const filePath = path.join(__dirname, `../../${randFileName}.pdf`);
    await generatePdf(html, filePath, kafkaHeaders, correlationId, kafkaData);
    //for web, return the base64 string, for mobile send email instead
    if (kafkaData.body.isWeb) {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const pdf2base64 = require('pdf-to-base64');
      const base64PDF = await pdf2base64(filePath);
      const producer = await createProducer();
      const producerOptions = getPDFandExcelProducerOptions(
        kafkaHeaders,
        base64PDF,
        kafkaData.body.name,
        correlationId
      );
      await producer.send(producerOptions);
    } else {
      const sentStatementEmailBody =
        kafkaData.body.sentStatementEmailBody || ESendStatement.DEFAULT_EMAIL_BODY;
      const fn = pug.compileFile(path.join(__dirname, '../../emails/statement.pug'));
      const html = fn({ sentStatementEmailBody });
      const attachments = [
        {
          filename: kafkaData.body.name,
          path: filePath,
          cid: kafkaData.body.name
        },
        {
          filename: 'main_1.png',
          path: path.join(__dirname, '../../images/main_1.png'),
          cid: 'main_1'
        }
      ];

      await sendFileEmail(
        kafkaData.body.email,
        ESendStatement.EMAIL_SUBJECT,
        attachments,
        correlationId,
        html
      );
    }
    fs.unlinkSync(filePath);
    logger.info(`Success in creating pdf table and send email to ${kafkaData.body.email}`, {
      correlationId,
      status: 200
    });
  } catch (e) {
    logger.error(e.message, { correlationId, status: 500 });
    fs.unlinkSync(path.join(__dirname, `../../${kafkaData.body.name}`));
  }
};
/*
export const generatePDFFTable = async (
  message: any,
  correlationId: string,
  kafkaHeaders: { replyTopic: string; partitionReply: number }
) => {
  const kafkaData = JSON.parse(message);
  try {
    const kafkaData = JSON.parse(message);
    const doc = new PdfDocument({
      size: 'A4',
      margin: 15
    });
    const stream = doc.pipe(fs.createWriteStream(kafkaData.body.name));

    const headers = Object.keys(kafkaData.body.data[0]);

    const rows = fixPDFRecords(kafkaData.body.data);
    const table = {
      title: kafkaData.body.title,
      headers,
      rows
    };

    await doc.table(table, {
      minRowHeight: 50,
      columnsSize: [200, 50, 50, 50, 50, 50, 40, 50]
    });
    doc.end();

    const filePath = path.join(__dirname, `../../${kafkaData.body.name}`);
    //for web, return the base64 string, for mobile send email instead
    if (kafkaData.body.isWeb) {
      //wait until the pdf is created
      stream.on('finish', async () => {
        // eslint @typescript-eslint/no-var-requires: "off"
        const pdf2base64 = require('pdf-to-base64');
        const base64PDF = await pdf2base64(filePath);
        const producer = await createProducer();
        const producerOptions = getPDFandExcelProducerOptions(
          kafkaHeaders,
          base64PDF,
          kafkaData.body.name,
          correlationId
        );
        await producer.send(producerOptions);
        fs.unlinkSync(filePath);
      });
    } else {
      const sentStatementEmailBody =
        kafkaData.body.sentStatementEmailBody || ESendStatement.DEFAULT_EMAIL_BODY;
      const fn = pug.compileFile(path.join(__dirname, '../../emails/statement.pug'));
      const html = fn({ sentStatementEmailBody });
      const attachments = [
        {
          filename: kafkaData.body.name,
          path: filePath,
          cid: kafkaData.body.name
        },
        {
          filename: 'main_1.png',
          path: path.join(__dirname, '../../images/main_1.png'),
          cid: 'main_1'
        }
      ];

      await sendFileEmail(
        kafkaData.body.email,
        ESendStatement.EMAIL_SUBJECT,
        attachments,
        correlationId,
        html
      );
      fs.unlinkSync(filePath);
    }
    logger.info('Success in creating pdf table', { correlationId, status: 200 });
  } catch (e) {
    logger.error(e.message, { correlationId, status: 500 });
    fs.unlinkSync(path.join(__dirname, `../../${kafkaData.body.name}`));
  }
};
*/
const getPDFandExcelProducerOptions = (
  kafkaHeaders: any,
  base64Data: string,
  fileName: string,
  correlationId: any
) => {
  return {
    topic: kafkaHeaders.replyTopic.toString(),
    compression: CompressionTypes.GZIP,
    messages: [
      {
        value: JSON.stringify({ message: { base64Data, fileName: fileName } }),
        partition: kafkaHeaders.partitionReply,
        headers: {
          correlationId: correlationId
        }
      }
    ]
  };
};

export const sendFileEmail = async (
  to: string,
  subject: string,
  attachments: any,
  correlationId: string,
  body: any
) => {
  try {
    const transporter = nodemailer.createTransport({
      host: config.smtpCredentials.host,
      port: Number(config.smtpCredentials.port),
      ...(config.smtpCredentials.username &&
        config.smtpCredentials.password && {
          auth: {
            user: config.smtpCredentials.username,
            pass: config.smtpCredentials.password
          }
        }),
      tls: { rejectUnauthorized: false }
    });
    await transporter.sendMail({
      from: config.smtpCredentials.email.from,
      to,
      subject,
      attachments,
      html: body
    });
    logger.info('Success in sending file email', { correlationId, status: 200 });
  } catch (e) {
    logger.error(e.message);
  }
};

export const fixPDFRecords = (data: any) => {
  let keys = [];
  return data.map((item: any) => {
    keys = Object.keys(item);
    return keys.map((key: string) => {
      return item[key];
    });
  });
};

export const sendNotification = async (
  message: string,
  headers: { replyTopic: string; partitionReply: number },
  correlationId: string
) => {
  const kafkaData = JSON.parse(message);
  const notificationToSend = {
    notification: {
      title: kafkaData.title,
      body: kafkaData.message
    },
    android: {
      notification: {
        sound: 'default'
      }
    },
    apns: {
      payload: {
        aps: {
          sound: 'default'
        }
      }
    },
    token: kafkaData.pushId
  };
  try {
    await firebaseService.sendNotification(notificationToSend);
    logger.info('Success in sending notification', { correlationId, status: 200 });
    const producer = await createProducer();
    const producerOptions: ProducerRecord = {
      topic: headers.replyTopic.toString(),
      compression: CompressionTypes.GZIP,
      messages: [
        {
          value: JSON.stringify({ message: 'Success' }),
          partition: headers.partitionReply,
          headers: {
            correlationId: correlationId
          }
        }
      ]
    };
    await producer.send(producerOptions);
  } catch (e) {
    logger.error(e.message);
  }
};
export const handlePortfolio = async (message: any, correlationId: string) => {
  const kafkaData = JSON.parse(message);
  const fileName = `${kafkaData.cif}.${new Date().getTime().toString()}.pdf`;
  const filePath = path.join(__dirname, `../../${fileName}`);
  try {
    const axiosData = await axios.get(`${config.FILENET_BASE_URL}${kafkaData.route}`, {
      timeout: config.axiosTimeOut,
      responseType: 'stream',
      headers: {
        'Content-Type': 'application/json',
        Authorization: kafkaData.Authorization || kafkaData.authorization || '',
        'x-correlation-id': correlationId
      }
    });
    const fn = pug.compileFile(path.join(__dirname, '../../emails/portfolio.pug'));
    const html = fn();
    await writeFile(axiosData.data, fileName);
    const dobString = kafkaData.dateOfBirth.toString();
    const dateOfBirthString = dobString.slice(-2) + dobString.slice(4, 6) + dobString.slice(2, 4);

    const pdfPassword = kafkaData.phoneNumber.slice(-4) + dateOfBirthString;

    const encryptedPDfPath = filePath.replace('pdf', 'encrypted.pdf');
    const pdfOptions = {
      input: filePath,
      output: encryptedPDfPath,
      password: pdfPassword
    };
    await qpdf.encrypt(pdfOptions);

    const attachments = [
      {
        filename: 'main_1.png',
        path: path.join(__dirname, '../../images/main_1.png'),
        cid: 'main_1'
      },
      {
        filename: `${kafkaData.cif} Portfolio statement.pdf`,
        path: encryptedPDfPath,
        cid: fileName
      }
    ];
    await sendFileEmail(
      kafkaData.email,
      `Portfolio Statement for user ${kafkaData.cif}`,
      attachments,
      correlationId,
      html
    );
    fs.unlinkSync(filePath);
    fs.unlinkSync(encryptedPDfPath);
    logger.info('Success in sending file email', { correlationId, status: 200 });
  } catch (e) {
    logger.error('Error in sending portfolio', { correlationId, status: 500 });
    logger.error(e.message);
  }
};

export const writeFile = async (stream: any, fileName: string) => {
  return new Promise((resolve) => {
    const writer = fs.createWriteStream(fileName);
    stream.pipe(writer);
    writer.on('finish', resolve);
  });
};

const generatePdf = async (
  html: any,
  filePath: string,
  kafkaHeaders: any,
  correlationId: string,
  kafkaData: any
) => {
  return new Promise<void>((resolve, reject) => {
    try {
      wkhtmltopdf(html, { output: filePath, ignore: [/QFont::setPixelSize/] }, async (err) => {
        if (err) {
          console.error('Error generating PDF:', err.message);
          console.error('Stack trace:', err.stack);
          reject(err);
        } else {
          if (fs.existsSync(filePath)) {
            const base64String = await pdf2base64(filePath);
            const producer = await createProducer();
            const producerOptions = getPDFandExcelProducerOptions(
              kafkaHeaders,
              base64String,
              kafkaData.body.name,
              correlationId
            );
            await producer.send(producerOptions);
            logger.info('Success in generating the pdf file', { correlationId, status: 200 });
            resolve();
          } else {
            reject(new Error('File does not exist.'));
          }
        }
      });
    } catch (e) {
      logger.error(`Error while generating the pdf file ${e.message}`, {
        correlationId,
        status: 200
      });
      reject(e);
    }
  });
};
