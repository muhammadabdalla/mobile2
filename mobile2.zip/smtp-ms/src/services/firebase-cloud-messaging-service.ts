/* eslint @typescript-eslint/no-var-requires: "off" */

import * as admin from 'firebase-admin';
import { Message } from 'firebase-admin/lib/messaging/messaging-api';
import { logger } from '../core/Logger';
import { firebaseConfig } from '../config';

const serviceAccount = require(firebaseConfig.pathToServiceAccount);
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

export async function sendNotification(message: Message) {
  try {
    await admin.messaging().send(message);
  } catch (error) {
    logger.error(error.message);
    throw error;
  }
}
