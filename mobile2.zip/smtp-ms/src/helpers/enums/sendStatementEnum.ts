export enum ESendStatement {
  DEFAULT_EMAIL_BODY = 'Kindly find attached your last 90-day transactions from your current account EGP.',
  EMAIL_SUBJECT = 'Current Account EGP Statement'
}
