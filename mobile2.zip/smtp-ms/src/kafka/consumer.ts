import { Consumer, Kafka } from 'kafkajs';
import { kafkaOptions, kafkaTopics } from '../config';
import { logger } from '../core/Logger';
import {
  generateExcelTable,
  generatePDFFTable,
  sendNotification,
  handlePortfolio,
  sendEmailService,
  generateTransferReceipt
} from '../services';

let consumer: Consumer;
let client: any;
let interval: number;
export const connector = () => {
  return new Kafka({
    clientId: kafkaOptions.clientId,
    brokers: kafkaOptions.hosts,
    connectionTimeout: kafkaOptions.connectionTimeout,
    requestTimeout: kafkaOptions.requestTimeout,
    retry: {
      initialRetryTime: kafkaOptions.initialRetryTime,
      retries: kafkaOptions.retries
    }
  });
};

export const createKafkaClient = () => {
  if (client) return client;
  return new Kafka({
    clientId: kafkaOptions.clientId,
    brokers: kafkaOptions.hosts,
    connectionTimeout: kafkaOptions.connectionTimeout,
    requestTimeout: kafkaOptions.requestTimeout,
    retry: {
      initialRetryTime: kafkaOptions.initialRetryTime,
      retries: kafkaOptions.retries
    }
  });
};

export const createConsumer = async () => {
  try {
    client = createKafkaClient();
    await createKafkaTopics(kafkaTopics.smtp, kafkaOptions.numberOfPartitions);
    consumer = await client.consumer(kafkaOptions.consumerPolicy);
    await consumer.connect();
    await consumer.subscribe({ topic: kafkaTopics.smtp });
    consumer.on(consumer.events.HEARTBEAT, ({ timestamp }) => {
      interval = timestamp;
    });
    await consumer.run({
      eachMessage: async ({ message }) => {
        if (!message.headers || !message.value) {
          logger.error('Missing required fields');
        } else {
          switch (message.headers?.function?.toString()) {
            case 'sendEmailService':
              sendEmailService(
                message.value.toString(),
                String(message.headers?.correlationId?.toString())
              ).catch((e) => logger.error(e.message));
              break;
            case 'generateExcelFile':
              generateExcelTable(
                message.value.toString(),
                String(message.headers?.correlationId?.toString()),
                {
                  replyTopic: String(message.headers?.replyTopic),
                  partitionReply: Number(message.headers?.partitionReply)
                }
              ).catch((e) => logger.error(e.message));
              break;
            case 'generatePDFFile':
              generatePDFFTable(
                message.value.toString(),
                String(message.headers?.correlationId?.toString()),
                {
                  replyTopic: String(message.headers?.replyTopic),
                  partitionReply: Number(message.headers?.partitionReply)
                }
              ).catch((e) => logger.error(e.message));
              break;
            case 'generateTransferReceipt':
              generateTransferReceipt(
                message.value.toString(),
                String(message.headers?.correlationId?.toString()),
                {
                  replyTopic: String(message.headers?.replyTopic),
                  partitionReply: Number(message.headers?.partitionReply)
                }
              ).catch((e) => logger.error(e.message));
              break;
            case 'sendNotification':
              sendNotification(
                message.value.toString(),
                {
                  replyTopic: String(message.headers?.replyTopic),
                  partitionReply: Number(message.headers?.partitionReply)
                },
                String(message.headers?.correlationId)
              ).catch((e: any) => logger.error(e.message));
              break;
            case 'sendPortfolioStatement':
              handlePortfolio(
                message.value.toString(),
                String(message.headers?.correlationId?.toString())
              );
              break;
          }
        }
      }
    });
  } catch (e) {
    logger.debug(e.message);
  }
};

export const getHeartbeatTime = async () => {
  return {
    consumer,
    interval
  };
};

export const createKafkaTopics = async (topic: string, partitionNumber: number) => {
  const admin = client.admin();
  try {
    const topicData = await admin.fetchTopicMetadata({ topics: [topic] });
    if (topicData && topicData.topics && topicData.topics.length) {
      if (topicData.topics[0].partitions.length < partitionNumber) {
        await admin.createPartitions({
          timeout: 5000,
          topicPartitions: [
            {
              topic,
              count: partitionNumber
            }
          ]
        });
      }
    }
  } catch (e) {
    if (e.message === 'This server does not host this topic-partition') {
      await admin.createTopics({
        validateOnly: false,
        waitForLeaders: false,
        timeout: 5000,
        topics: [
          {
            topic,
            numPartitions: partitionNumber,
            replicationFactor: 1,
            replicaAssignment: [],
            configEntries: []
          }
        ]
      });
    } else {
      throw new Error(e);
    }
  }
};
