import express from 'express';
import { SuccessResponse } from '../../core/ApiResponse';
import asyncHandler from '../../helpers/asyncHandler';
import * as service from '../../services/mapping';
import authenticate from '../../helpers/authenticate';
import { ProtectedRequest } from 'app-request';

const router = express.Router();

router.get(
  '/',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getMappingData(req.headers['accept-language']);
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/card',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getCardMappingData(req.headers['accept-language']);
    new SuccessResponse('Success', result).send(res);
  })
);
export default router;
