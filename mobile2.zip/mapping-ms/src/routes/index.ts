import express from 'express';
import accounts from './mapping/mapping';

const router = express.Router();

router.use('/mapping', accounts);

export default router;
