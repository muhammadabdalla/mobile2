export const mapping: any = {
  en: [
    {
      key: 'Certificate Dep',
      value: 'Certificates of Deposits',
      language: 'en'
    },
    {
      key: 'Time Deposits',
      value: 'Time Deposits',
      language: 'en'
    },
    {
      key: 'Long Term T/D',
      value: 'Long Term Time Deposits',
      language: 'en'
    },
    {
      key: 'CurrAcc Demand',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'Current Accounts - Demand',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'CurrAcc Call',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'Current Accounts - Call',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'CORPERATE WEALT',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'INDIVDUAL WEALT',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'INDIVIDUAL EDGE',
      value: 'Current Account',
      language: 'en'
    },
    {
      key: 'SAVING AC MONTH',
      value: 'Savings Account',
      language: 'en'
    },
    {
      key: 'SAVING AC QUART',
      value: 'Savings Account',
      language: 'en'
    },
    {
      key: 'SAVING AC SEM A',
      value: 'Savings Account',
      language: 'en'
    },
    {
      key: 'SAVING AC ANUAL',
      value: 'Savings Account',
      language: 'en'
    },
    {
      key: 'Staff Account',
      value: 'Savings Staff Account',
      language: 'en'
    },
    {
      key: 'GOLDEN SAVING',
      value: 'Golden Saving Plus account',
      language: 'en'
    },
    {
      key: 'Unsecure R.Loan',
      value: 'Unsecure Retail Loans',
      language: 'en'
    },
    {
      key: 'Secure Retail L',
      value: 'Secured Retail Loans',
      language: 'en'
    },
    {
      key: 'Semi-Secure R L',
      value: 'Semi-Secure Retail Loans',
      language: 'en'
    },
    {
      key: 'Credit Card',
      value: 'Credit Cards',
      language: 'en'
    },
    {
      key: 'VS LOCAL SEC.',
      value: 'Visa Card - Local Secured',
      language: 'en'
    },
    {
      key: 'VS CLASSIC SEC.',
      value: 'Visa Card - Classic Secured',
      language: 'en'
    },
    {
      key: 'VS GOLD SEC.',
      value: 'Visa Card - Gold Secured',
      language: 'en'
    },
    {
      key: 'MC CLASSIC SEC.',
      value: 'Master Card - Classic Secured',
      language: 'en'
    },
    {
      key: 'MC CLASSIC CHIP',
      value: 'MASTER CARD - Classic CHIP Sec',
      language: 'en'
    },
    {
      key: 'VS PLATINUM SEC',
      value: 'Visa Card - Platinum Retail Se',
      language: 'en'
    },
    {
      key: 'VS PLATINUM SEC',
      value: 'Visa Card - Platinum Wealth Se',
      language: 'en'
    },
    {
      key: 'MC TITANUM SEC',
      value: 'Master Card - TITANIUM Secured',
      language: 'en'
    },
    {
      key: 'MC TITANUM INST',
      value: 'Master Card - TITANIUM install',
      language: 'en'
    },
    {
      key: 'VS LOCAL UNSEC.',
      value: 'Visa Card - Local Unsecured',
      language: 'en'
    },
    {
      key: 'VS CLASIC UNSEC',
      value: 'Visa Card - Classic Unsecured',
      language: 'en'
    },
    {
      key: 'VS GOLD UNSEC',
      value: 'Visa Card - Gold Unsecured',
      language: 'en'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'Master Card - Classic Unsecured',
      language: 'en'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'MASTER CARD - Classic CHIP Unsecure',
      language: 'en'
    },
    {
      key: 'VS PLATIN.UNSEC',
      value: 'Visa Card - Platinum Retail Unsecur',
      language: 'en'
    },
    {
      key: 'VS PLATIN.UNSEC',
      value: 'Visa Card - Platinum Wealth Unsecur',
      language: 'en'
    },
    {
      key: 'MC TITANM UNSEC',
      value: 'Master Card - TITANIUM Unsecured',
      language: 'en'
    },
    {
      key: 'MC TITANUM INST',
      value: 'Master Card - TITANIUM installment',
      language: 'en'
    },
    {
      key: 'VS LOCAL UNSEC.',
      value: 'Visa Card - Local Unsecured',
      language: 'en'
    },
    {
      key: 'VS CLASIC UNSEC',
      value: 'Visa Card - Classic Unsecured',
      language: 'en'
    },
    {
      key: 'VS GOLD UNSEC',
      value: 'Visa Card - Gold Unsecured',
      language: 'en'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'Master Card - Classic Unsecure',
      language: 'en'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'MASTER CARD - Classic CHIP Uns',
      language: 'en'
    },
    {
      key: 'VS PLATIN UNSEC',
      value: 'Visa Card - Platinum Retail Un',
      language: 'en'
    },
    {
      key: 'VS PLATIN UNSEC',
      value: 'Visa Card - Platinum Wealth Un',
      language: 'en'
    },
    {
      key: 'MC TITANM UNSEC',
      value: 'Master Card - TITANIUM Unsecur',
      language: 'en'
    },
    {
      key: 'MC TITANM INSTL',
      value: 'Master Card - TITANIUM install',
      language: 'en'
    }
  ],
  ar: [
    {
      key: 'Certificate Dep',
      value: 'شهادات ادخار',
      language: 'ar'
    },
    {
      key: 'Time Deposits',
      value: 'ودائع',
      language: 'ar'
    },
    {
      key: 'Long Term T/D',
      value: 'الودائع طويلة الأجل',
      language: 'ar'
    },
    {
      key: 'CurrAcc Demand',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'Current Accounts - Demand',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'CurrAcc Call',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'Current Accounts - Call',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'CORPERATE WEALT',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'INDIVDUAL WEALT',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'INDIVIDUAL EDGE',
      value: 'حساب جاري',
      language: 'ar'
    },
    {
      key: 'SAVING AC MONTH',
      value: 'حساب توفير',
      language: 'ar'
    },
    {
      key: 'SAVING AC QUART',
      value: 'حساب توفير',
      language: 'ar'
    },
    {
      key: 'SAVING AC SEM A',
      value: 'حساب توفير',
      language: 'ar'
    },
    {
      key: 'SAVING AC ANUAL',
      value: 'حساب توفير',
      language: 'ar'
    },
    {
      key: 'Staff Account',
      value: 'حساب توفير للموظف',
      language: 'ar'
    },
    {
      key: 'GOLDEN SAVING',
      value: 'حساب توفير جولدن بلس',
      language: 'ar'
    },
    {
      key: 'Unsecure R.Loan',
      value: 'قروض أفراد',
      language: 'ar'
    },
    {
      key: 'Secure Retail L',
      value: 'قروض أفراد بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'Semi-Secure R L',
      value: 'قروض أفراد بضمان جزئي',
      language: 'ar'
    },
    {
      key: 'Credit Card',
      value: 'بطاقات إئتمان',
      language: 'ar'
    },
    {
      key: 'VS LOCAL SEC.',
      value: 'بطاقة فيزا - محلية بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'VS CLASSIC SEC.',
      value: 'بطاقة فيزا - الكلاسيكية بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'VS GOLD SEC.',
      value: 'بطاقة فيزا - الذهبية بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'MC CLASSIC SEC.',
      value: 'بطاقة ماستر - الكلاسيكية بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'MC CLASSIC CHIP',
      value: 'بطاقة ماستر - الكلاسيكية بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'VS PLATINUM SEC',
      value: 'بطاقة فيزا - بلاتينوم أفراد بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'VS PLATINUM SEC',
      value: 'بطاقة فيزا - بلاتينوم ثروات بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'MC TITANUM SEC',
      value: 'بطاقة ماستر - تيتانيوم بضمان نقدي',
      language: 'ar'
    },
    {
      key: 'MC TITANUM INST',
      value: 'بطاقة ماستر - تيتانيوم تقسيط',
      language: 'ar'
    },
    {
      key: 'VS LOCAL UNSEC.',
      value: 'بطاقة فيزا - محلية',
      language: 'ar'
    },
    {
      key: 'VS CLASIC UNSEC',
      value: 'بطاقة فيزا - الكلاسيكية',
      language: 'ar'
    },
    {
      key: 'VS GOLD UNSEC',
      value: 'بطاقة فيزا - الذهبية',
      language: 'ar'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'بطاقة ماستر - الكلاسيكية',
      language: 'ar'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'بطاقة ماستر - الكلاسيكية',
      language: 'ar'
    },
    {
      key: 'VS PLATIN.UNSEC',
      value: 'بطاقة فيزا - البلاتينية أفراد',
      language: 'ar'
    },
    {
      key: 'VS PLATIN.UNSEC',
      value: 'بطاقة فيزا - البلاتينية ثروات',
      language: 'ar'
    },
    {
      key: 'MC TITANM UNSEC',
      value: 'بطاقة ماستر - تيتانيوم',
      language: 'ar'
    },
    {
      key: 'MC TITANUM INST',
      value: 'بطاقة ماستر - تيتانيوم تقسيط',
      language: 'ar'
    },
    {
      key: 'VS LOCAL UNSEC.',
      value: 'بطاقة فيزا - محلية',
      language: 'ar'
    },
    {
      key: 'VS CLASIC UNSEC',
      value: 'بطاقة فيزا - الكلاسيكية',
      language: 'ar'
    },
    {
      key: 'VS GOLD UNSEC',
      value: 'بطاقة فيزا - الذهبية',
      language: 'ar'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'بطاقة ماستر - الكلاسيكية',
      language: 'ar'
    },
    {
      key: 'MC CLASIC UNSEC',
      value: 'بطاقة ماستر - الكلاسيكية',
      language: 'ar'
    },
    {
      key: 'VS PLATIN UNSEC',
      value: 'بطاقة فيزا - البلاتينية أفراد',
      language: 'ar'
    },
    {
      key: 'VS PLATIN UNSEC',
      value: 'بطاقة فيزا - البلاتينية ثروات',
      language: 'ar'
    },
    {
      key: 'MC TITANM UNSEC',
      value: 'بطاقة ماستر - تيتانيوم',
      language: 'ar'
    },
    {
      key: 'MC TITANM INSTL',
      value: 'بطاقة ماستر - تيتانيوم تقسيط',
      language: 'ar'
    }
  ]
};

export const debitMapping: any = {
  en: [
    {
      'E-proofNumber': '4524',
      BIN: 415326,
      cardName: 'Visa Gold Credit Card',
      cardType: 'Credit Card',
      EGP: 225,
      USD: 0,
      language: 'en',
      interestRate: 2.65
    },
    {
      'E-proofNumber': '4526',
      BIN: 469680,
      cardName: 'Visa Platinum Credit Card',
      cardType: 'Credit Card',
      EGP: 300,
      USD: 0,
      language: 'en',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '4527',
      BIN: 458783,
      cardName: 'Visa Platinum Wealth Credit Card',
      cardType: 'Credit Card',
      EGP: 300,
      USD: 0,
      language: 'en',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '4520',
      BIN: 527109,
      cardName: 'MasterCard Titanium Credit Card',
      cardType: 'Credit Card',
      EGP: 225,
      USD: 0,
      language: 'en',
      interestRate: 2.65
    },
    {
      'E-proofNumber': '5027',
      BIN: 515485,
      cardName: 'MasterCard World Elite Credit Card',
      cardType: 'Credit Card',
      EGP: 2500,
      USD: 0,
      language: 'en',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '5026',
      BIN: 403010,
      cardName: 'Visa Signature Credit Card',
      cardType: 'Credit Card',
      EGP: 1500,
      USD: 0,
      language: 'en',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '5150',
      BIN: 465578,
      cardName: 'Visa Platinum Debit Card',
      cardType: 'Debit Card',
      EGP: 100,
      USD: 0,
      language: 'en'
    },
    {
      'E-proofNumber': '5154',
      BIN: 558587,
      cardName: 'MasterCard Platinum Debit Card',
      cardType: 'Debit Card',
      EGP: 100,
      USD: 0,
      language: 'en'
    },
    {
      'E-proofNumber': '4522',
      BIN: 460014,
      cardName: 'Visa Classic Debit Card',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'en'
    },
    {
      'E-proofNumber': '4521',
      BIN: 476575,
      cardName: 'Visa Classic Debit Card (USD)',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'en'
    },
    {
      'E-proofNumber': '4519',
      BIN: 537017,
      cardName: 'MasterCard Classic Debit Card',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'en'
    },
    {
      'E-proofNumber': '5002',
      BIN: 530509,
      cardName: 'MasterCard Debit Card',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'en'
    },
    {
      'E-proofNumber': '4524',
      BIN: 454835,
      cardName: 'Visa Gold Credit Card',
      cardType: 'Credit Card',
      EGP: 225,
      USD: 0,
      language: 'en',
      interestRate: 2.65
    }
  ],
  ar: [
    {
      'E-proofNumber': '4524',
      BIN: 415326,
      cardName: 'بطاقة إئتمان فيزا الذهبية',
      cardType: 'Credit Card',
      EGP: 225,
      USD: 0,
      language: 'ar',
      interestRate: 2.65
    },
    {
      'E-proofNumber': '4526',
      BIN: 469680,
      cardName: 'بطاقة إئتمان فيزا البلاتينية',
      cardType: 'Credit Card',
      EGP: 300,
      USD: 0,
      language: 'ar',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '4527',
      BIN: 458783,
      cardName: 'بطاقة إئتمان فيزا البلاتينية ثروات',
      cardType: 'Credit Card',
      EGP: 300,
      USD: 0,
      language: 'ar',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '4520',
      BIN: 527109,
      cardName: 'بطاقة إئتمان ماستر كارد تيتانيوم',
      cardType: 'Credit Card',
      EGP: 225,
      USD: 0,
      language: 'ar',
      interestRate: 2.65
    },
    {
      'E-proofNumber': '5027',
      BIN: 515485,
      cardName: 'بطاقة إئتمان ماستر كارد World Elite',
      cardType: 'Credit Card',
      EGP: 2500,
      USD: 0,
      language: 'ar',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '5026',
      BIN: 403010,
      cardName: 'بطاقة إئتمان فيزا Signature',
      cardType: 'Credit Card',
      EGP: 1500,
      USD: 0,
      language: 'ar',
      interestRate: 2.45
    },
    {
      'E-proofNumber': '5150',
      BIN: 465578,
      cardName: 'بطاقة خصم فيزا البلاتينية',
      cardType: 'Debit Card',
      EGP: 100,
      USD: 0,
      language: 'ar'
    },
    {
      'E-proofNumber': '5154',
      BIN: 558587,
      cardName: 'بطاقة خصم ماستر كارد البلاتينية',
      cardType: 'Debit Card',
      EGP: 100,
      USD: 0,
      language: 'ar'
    },
    {
      'E-proofNumber': '4522',
      BIN: 460014,
      cardName: 'بطاقة خصم فيزا الكلاسيكية',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'ar'
    },
    {
      'E-proofNumber': '4521',
      BIN: 476575,
      cardName: 'بطاقة خصم فيزا الكلاسيكية (دولار)',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'ar'
    },
    {
      'E-proofNumber': '4519',
      BIN: 537017,
      cardName: 'بطاقة خصم ماستر كارد الكلاسيكية',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'ar'
    },
    {
      'E-proofNumber': '5002',
      BIN: 530509,
      cardName: 'بطاقة خصم ماستر كارد',
      cardType: 'Debit Card',
      EGP: 60,
      USD: 3,
      language: 'ar'
    },
    {
      'E-proofNumber': '4524',
      BIN: 454835,
      cardName: 'بطاقة إئتمان فيزا الذهبية',
      cardType: 'Credit Card',
      EGP: 225,
      USD: 0,
      language: 'ar',
      interestRate: 2.65
    }
  ]
};
