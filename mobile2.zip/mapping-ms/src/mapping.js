const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, './source/accountMapping.xlsx');
const data = fs.readFileSync(filePath);
const excelData = XLSX.read(data, { type: 'buffer' });
const sheet = excelData.Sheets[excelData.SheetNames[0]];
const jsonData = XLSX.utils.sheet_to_json(sheet);
jsonData.shift();
const cleanData = {
  en: []
};
jsonData.map((item) => {
  let record = {};
  if (item['__EMPTY_5']) {
    item['__EMPTY_5'] = item['__EMPTY_5'].replace("+ 'currency'", '{Currency}');
    record.description = item['__EMPTY_2'];
  }
  record.key = item['__EMPTY_3'];
  record.value = item['__EMPTY_5'] || item['__EMPTY_2'];
  cleanData.en.push(record);
});
fs.writeFile('./mapping.json', JSON.stringify(cleanData), 'utf8', () => {});
